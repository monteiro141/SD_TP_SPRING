package com.example.noticiasquentinhas.forms;

public class TopicFormSubscriber {
    private String [] name;

    public TopicFormSubscriber() {
    }

    public String[] getName() {
        return name;
    }

    public void setName(String[] name) {
        this.name = name;
    }
}
