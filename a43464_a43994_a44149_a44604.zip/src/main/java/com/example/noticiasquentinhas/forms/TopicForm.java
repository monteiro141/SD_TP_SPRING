package com.example.noticiasquentinhas.forms;

public class TopicForm {
    private String name;

    public TopicForm() {
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }
}
